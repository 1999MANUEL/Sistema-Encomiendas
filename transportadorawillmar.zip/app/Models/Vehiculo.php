<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use App\Enums\VehiculosEstado; // Importa tu Enum de estados de vehículo

class Vehiculo extends Model
{
    use HasFactory;

    protected $table = 'vehiculos'; // Especificar el nombre de la tabla si no sigue la convención

    protected $fillable = [
        'marca',
        'modelo',
        'placa',
        'estado',
    ];

    protected $casts = [
        'estado' => VehiculosEstado::class, // Vincula el campo 'estado' con tu Enum
    ];

    /**
     * Define la relación Muchos a Muchos con Conductor.
     */
    public function conductores(): BelongsToMany
    {
        return $this->belongsToMany(Conductor::class, 'conductor_vehiculo', 'vehiculo_id', 'conductor_id')
            ->withPivot('fecha_inicio_asignacion', 'fecha_fin_asignacion', 'rol_conductor')
            ->withTimestamps();
    }

    /**
     * Atributo para obtener la descripción completa del vehículo.
     * Útil para mostrar en la UI de Filament o en cualquier otro lugar.
     */
    public function getDescripcionCompletaAttribute(): string
    {
        return "{$this->marca} {$this->modelo} ({$this->placa})";
    }
}
