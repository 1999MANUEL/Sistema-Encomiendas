<?php

namespace App\Models;

use App\Enums\ConductoresEstado;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
// Asumiendo que crearás este Enum similar a VehiculosEstado

class Conductor extends Model
{
    use HasFactory;

    protected $table = 'conductores'; // Especificar el nombre de la tabla si no sigue la convención de pluralización

    protected $fillable = [
        'nombre_conductor',
        'celular_conductor',
        'conductor_num_licencia',
        'fecha_exp_licencia',
        'fecha_contratacion',
        'estado',
    ];

    protected $casts = [
        'fecha_exp_licencia' => 'date',
        'fecha_contratacion' => 'date',
        'estado' => ConductoresEstado::class,
    ];

    /**
     * Define la relación Muchos a Muchos con Vehiculo.
     */
    public function vehiculos(): BelongsToMany
    {
        return $this->belongsToMany(Vehiculo::class, 'conductor_vehiculo', 'conductor_id', 'vehiculo_id')
            ->withPivot('fecha_inicio_asignacion', 'fecha_fin_asignacion', 'rol_conductor')
            ->withTimestamps(); // Incluye created_at y updated_at de la tabla pivote
    }

    /**
     * Atributo para obtener el nombre completo del conductor.
     * Útil para mostrar en la UI de Filament o en cualquier otro lugar.
     */
    public function getNombreCompletoAttribute(): string
    {
        return $this->nombre_conductor;
    }
}
