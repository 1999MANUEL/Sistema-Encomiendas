<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Factura Encomienda</title>
    <style>
        @page {
            margin: 0;
            size: 80mm auto;
            /* Ancho fijo 80mm, alto automático */
        }

        body {
            font-family: 'Courier New', monospace;
            font-size: 11px;
            color: #000;
            margin: 0;
            padding: 4mm;
            width: 72mm;
            /* Ancho exacto de impresión */
            min-height: 100vh;
            line-height: 1.2;
        }

        /* Configuración específica para impresora térmica */
        @media print {
            @page {
                size: 80mm auto;
                margin: 0;
            }

            body {
                width: 72mm;
                padding: 2mm;
                font-size: 10px;
            }

            .receipt {
                width: 100%;
                max-width: 72mm;
            }
        }

        .receipt {
            width: 100%;
        }

        .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 1px dashed #000;
            padding-bottom: 5px;
        }

        .header h1 {
            font-size: 14px;
            font-weight: bold;
            margin: 0 0 5px 0;
        }

        .header p {
            margin: 2px 0;
            font-size: 10px;
        }

        .section {
            margin-bottom: 8px;
        }

        .section-title {
            font-weight: bold;
            font-size: 11px;
            border-bottom: 1px solid #000;
            margin-bottom: 3px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
            font-size: 10px;
        }

        .description {
            margin: 5px 0;
            font-size: 10px;
            word-wrap: break-word;
        }

        .package-item {
            border-bottom: 1px dotted #ccc;
            padding: 3px 0;
            margin-bottom: 3px;
        }

        .package-header {
            font-weight: bold;
            font-size: 10px;
        }

        .package-detail {
            font-size: 9px;
            margin: 1px 0;
        }

        .totals {
            border-top: 1px solid #000;
            padding-top: 5px;
            margin-top: 8px;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
            font-size: 10px;
        }

        .total-final {
            font-weight: bold;
            font-size: 12px;
            border-top: 1px solid #000;
            padding-top: 3px;
            margin-top: 5px;
        }

        .footer {
            text-align: center;
            font-size: 8px;
            margin-top: 10px;
            border-top: 1px dashed #000;
            padding-top: 5px;
        }

        .separator {
            text-align: center;
            margin: 5px 0;
            font-size: 10px;
        }

        @media print {
            body {
                width: 72mm;
            }
        }
    </style>
</head>

<body>
    <div class="receipt">
        <div class="header">
            <h1>TRANSPORTES</h1>
            <h1>WILL MAR</h1>
             <p>SANTA CRUZ - ORURO</p>
            <p>FACTURA ENCOMIENDA</p>
              <h1>   {{ strip_tags($encomienda->numero_guia) ?? 'No especificado' }}</h1>
            <p>Fecha: {{ now()->format('d/m/Y H:i') }}</p>
        </div>

        <div class="section">
            <div class="section-title">DESCRIPCION GENERAL</div>
            <div class="description">
                {{ strip_tags($encomienda->descripcion_contenido) ?? 'No especificado' }}
            </div>
        </div>

     
            <div class="section">
            <div class="section-title">DATOS DE ENVIO</div>
            <div class="description">
                Remitente: {{ strip_tags($encomienda->nombre_remitente) ?? 'No especificado' }}
            </div>
            <div class="description">
              Destinatario:  {{ strip_tags($encomienda->nombre_destinatario) ?? 'No especificado' }}
            </div>
        </div>

        

        <div class="section">
            <div class="section-title">DETALLE PAQUETES</div>
            @foreach($encomienda->paquetes as $index => $paquete)
            <div class="package-item">
                <div class="package-header">Paquete #{{ $index + 1 }}</div>
                <div class="package-detail">Peso: {{ number_format($paquete->peso, 2) }} kg</div>
                <div class="package-detail">Dim: {{ $paquete->alto }}x{{ $paquete->ancho }}x{{ $paquete->largo }} cm</div>
                <div class="package-detail">Contenido: {{ $paquete->descripcion ?? 'No especificado' }}</div>
                <div class="package-detail">Precio: Bs {{ number_format($paquete->precio, 2) }}</div>
            </div>
            @endforeach
        </div>

        <div class="separator">
            ================================
        </div>

        <div class="totals">
            <div class="total-row">
                <span>Peso total:</span>
                <span>{{ number_format($encomienda->paquetes->sum('peso'), 2) }} kg</span>
            </div>
            <div class="total-row">
                <span>Volumen total:</span>
                <span>{{ number_format($encomienda->paquetes->sum('alto') * $encomienda->paquetes->sum('ancho') * $encomienda->paquetes->sum('largo') / 1000000, 2) }} m³</span>
            </div>
            <div class="total-row">
                <span>Cantidad paquetes:</span>
                <span>{{ $encomienda->paquetes->count() }}</span>
            </div>

            <div class="total-row total-final">
                <span>TOTAL A PAGAR:</span>
                <span>Bs {{ number_format($encomienda->paquetes->sum('precio'), 2) }}</span>
               
            </div>
            <div class="total-row">
                 <span>Estado de Pago:</span>
                <span class="value">
                    @if ($encomienda->estado_pago === 'pagado')
                    <strong>PAGADO</strong>
                    @elseif ($encomienda->estado_pago === 'con_saldo')
                    <strong>CON SALDO</strong><br>
                    Monto Pagado: Bs {{ number_format($encomienda->monto_pagado, 2) }}<br>
                    Saldo Pendiente: <strong >Bs {{ number_format($encomienda->saldo_pendiente, 2) }}</strong>
                    @else
                    {{ $encomienda->estado_pago }}
                    @endif
                </span>

                @if ($encomienda->tiene_valor_declarado)
                <span >Valor Declarado:</span>
                <span>Bs {{ number_format($encomienda->valor_declarado, 2) }}</span>
                @endif
            </div>
        </div>

        <div class="separator">
            ================================
        </div>

        <div class="footer">
            <p>Transportes Will Mar © {{ now()->year }}</p>
            <p>Factura generada automaticamente</p>
            <p>Gracias por su confianza</p>
        </div>
    </div>
</body>

</html>