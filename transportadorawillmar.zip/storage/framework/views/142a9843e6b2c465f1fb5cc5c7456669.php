<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Factura Encomienda</title>
    <style>
        @page {
            margin: 0;
            size: 80mm auto;
            /* Ancho fijo 80mm, alto automático */
        }

        body {
            font-family: 'Courier New', monospace;
            font-size: 11px;
            color: #000;
            margin: 0;
            padding: 4mm;
            width: 72mm;
            /* Ancho exacto de impresión */
            min-height: 100vh;
            line-height: 1.2;
        }

        /* Configuración específica para impresora térmica */
        @media print {
            @page {
                size: 80mm auto;
                margin: 0;
            }

            body {
                width: 72mm;
                padding: 2mm;
                font-size: 10px;
            }

            .receipt {
                width: 100%;
                max-width: 72mm;
            }
        }

        .receipt {
            width: 100%;
        }

        .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 1px dashed #000;
            padding-bottom: 5px;
        }

        .header h1 {
            font-size: 14px;
            font-weight: bold;
            margin: 0 0 5px 0;
        }

        .header p {
            margin: 2px 0;
            font-size: 10px;
        }

        .section {
            margin-bottom: 8px;
        }

        .section-title {
            font-weight: bold;
            font-size: 11px;
            border-bottom: 1px solid #000;
            margin-bottom: 3px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
            font-size: 10px;
        }

        .description {
            margin: 5px 0;
            font-size: 10px;
            word-wrap: break-word;
        }

        .package-item {
            border-bottom: 1px dotted #ccc;
            padding: 3px 0;
            margin-bottom: 3px;
        }

        .package-header {
            font-weight: bold;
            font-size: 10px;
        }

        .package-detail {
            font-size: 9px;
            margin: 1px 0;
        }

        .totals {
            border-top: 1px solid #000;
            padding-top: 5px;
            margin-top: 8px;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
            font-size: 10px;
        }

        .total-final {
            font-weight: bold;
            font-size: 12px;
            border-top: 1px solid #000;
            padding-top: 3px;
            margin-top: 5px;
        }

        .footer {
            text-align: center;
            font-size: 8px;
            margin-top: 10px;
            border-top: 1px dashed #000;
            padding-top: 5px;
        }

        .separator {
            text-align: center;
            margin: 5px 0;
            font-size: 10px;
        }

        @media print {
            body {
                width: 72mm;
            }
        }
    </style>
</head>

<body>
    <div class="receipt">
        <div class="header">
            <h1>TRANSPORTES</h1>
            <h1>WILL MAR</h1>
             <p>SANTA CRUZ - ORURO</p>
            <p>FACTURA ENCOMIENDA</p>
              <h1>   <?php echo e(strip_tags($encomienda->numero_guia) ?? 'No especificado'); ?></h1>
            <p>Fecha: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
        </div>

        <div class="section">
            <div class="section-title">DESCRIPCION GENERAL</div>
            <div class="description">
                <?php echo e(strip_tags($encomienda->descripcion_contenido) ?? 'No especificado'); ?>

            </div>
        </div>

     
            <div class="section">
            <div class="section-title">DATOS DE ENVIO</div>
            <div class="description">
                Remitente: <?php echo e(strip_tags($encomienda->nombre_remitente) ?? 'No especificado'); ?>

            </div>
            <div class="description">
              Destinatario:  <?php echo e(strip_tags($encomienda->nombre_destinatario) ?? 'No especificado'); ?>

            </div>
        </div>

        

        <div class="section">
            <div class="section-title">DETALLE PAQUETES</div>
            <?php $__currentLoopData = $encomienda->paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="package-item">
                <div class="package-header">Paquete #<?php echo e($index + 1); ?></div>
                <div class="package-detail">Peso: <?php echo e(number_format($paquete->peso, 2)); ?> kg</div>
                <div class="package-detail">Dim: <?php echo e($paquete->alto); ?>x<?php echo e($paquete->ancho); ?>x<?php echo e($paquete->largo); ?> cm</div>
                <div class="package-detail">Contenido: <?php echo e($paquete->descripcion ?? 'No especificado'); ?></div>
                <div class="package-detail">Precio: Bs <?php echo e(number_format($paquete->precio, 2)); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="separator">
            ================================
        </div>

        <div class="totals">
            <div class="total-row">
                <span>Peso total:</span>
                <span><?php echo e(number_format($encomienda->paquetes->sum('peso'), 2)); ?> kg</span>
            </div>
            <div class="total-row">
                <span>Volumen total:</span>
                <span><?php echo e(number_format($encomienda->paquetes->sum('alto') * $encomienda->paquetes->sum('ancho') * $encomienda->paquetes->sum('largo') / 1000000, 2)); ?> m³</span>
            </div>
            <div class="total-row">
                <span>Cantidad paquetes:</span>
                <span><?php echo e($encomienda->paquetes->count()); ?></span>
            </div>

            <div class="total-row total-final">
                <span>TOTAL A PAGAR:</span>
                <span>Bs <?php echo e(number_format($encomienda->paquetes->sum('precio'), 2)); ?></span>
               
            </div>
            <div class="total-row">
                 <span>Estado de Pago:</span>
                <span class="value">
                    <?php if($encomienda->estado_pago === 'pagado'): ?>
                    <strong>PAGADO</strong>
                    <?php elseif($encomienda->estado_pago === 'con_saldo'): ?>
                    <strong>CON SALDO</strong><br>
                    Monto Pagado: Bs <?php echo e(number_format($encomienda->monto_pagado, 2)); ?><br>
                    Saldo Pendiente: <strong >Bs <?php echo e(number_format($encomienda->saldo_pendiente, 2)); ?></strong>
                    <?php else: ?>
                    <?php echo e($encomienda->estado_pago); ?>

                    <?php endif; ?>
                </span>

                <?php if($encomienda->tiene_valor_declarado): ?>
                <span >Valor Declarado:</span>
                <span>Bs <?php echo e(number_format($encomienda->valor_declarado, 2)); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="separator">
            ================================
        </div>

        <div class="footer">
            <p>Transportes Will Mar © <?php echo e(now()->year); ?></p>
            <p>Factura generada automaticamente</p>
            <p>Gracias por su confianza</p>
        </div>
    </div>
</body>

</html><?php /**PATH /home/victor-manuel/LaravelProyectos/TransportadoraWillmar/trasnportadorawillmar/resources/views/reportes/encomienda.blade.php ENDPATH**/ ?>